-- $Id: ddl_create_table_unsync_mng.sql,v 1.1.1.1 2007/07/26 05:41:59 cvs Exp $
-- Unsync_Terminal management table
-- Revision:$Revision: 1.1.1.1 $
-- Date:$Date: 2007/07/26 05:41:59 $
-- Author:$Author: cvs $

drop table unsync_mng;
create table unsync_mng (
  target_cs     char(8) not null,
  receive_time  timestamp not null,
  mod_date      timestamp default now()  not null,
  reg_date      timestamp default now()  not null,
  blacklist_flg boolean default FALSE not null,
  constraint PK_UNSYNC_MNG primary key (
    target_cs
  )
);

COMMENT ON TABLE unsync_mng IS 'Unsync_Terminal management table';
COMMENT ON COLUMN unsync_mng.target_cs IS 'target call sign';
COMMENT ON COLUMN unsync_mng.receive_time IS 'if location information changed,time changed';
COMMENT ON COLUMN unsync_mng.mod_date IS 'modify date for db';
COMMENT ON COLUMN unsync_mng.reg_date IS 'regist date for db';
COMMENT ON COLUMN unsync_mng.blacklist_flg  IS 'blacklist flag';


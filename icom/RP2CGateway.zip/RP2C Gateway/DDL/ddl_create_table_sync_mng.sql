-- $Id: ddl_create_table_sync_mng.sql,v 1.1.1.1 2007/07/26 05:41:59 cvs Exp $
-- Sync_Terminal management table
--
drop table sync_mng;
create table sync_mng (
  target_cs     char(8) not null,
  last_mod_time timestamp not null,
  mod_date      timestamp default now() not null,
  reg_date      timestamp default now() not null,
  pc_hostname   varchar(128) not null,
  arearp_cs     char(8) not null,
  zonerp_cs     char(8) not null,
  user_cs       char(8) not null,
  regist_rp_cs  char(8) not null,
  pc_ipaddr     inet not null,
  del_flg       boolean default FALSE not null,
  constraint PK_SYNC_MNG primary key (
    target_cs
  )
);

drop index IE1_SYNC_MNG;
create index IE1_SYNC_MNG on sync_mng ( user_cs, regist_rp_cs);

drop index IE2_SYNC_MNG;
create index IE2_SYNC_MNG on sync_mng (pc_hostname);

drop index IE3_SYNC_MNG;
create index IE3_SYNC_MNG on sync_mng (last_mod_time);

COMMENT ON TABLE sync_mng IS 'Sync_Terminal management table';
COMMENT ON COLUMN sync_mng.target_cs        IS 'target call sign';
COMMENT ON COLUMN sync_mng.last_mod_time    IS 'last modify date for sync';
COMMENT ON COLUMN sync_mng.mod_date         IS 'modify date for db';
COMMENT ON COLUMN sync_mng.reg_date         IS 'regist date for db';
COMMENT ON COLUMN sync_mng.pc_hostname      IS 'pc hostname';
COMMENT ON COLUMN sync_mng.arearp_cs        IS 'area repetar call sign';
COMMENT ON COLUMN sync_mng.zonerp_cs        IS 'zone repetar call sign';
COMMENT ON COLUMN sync_mng.user_cs          IS 'user repetar call sign';
COMMENT ON COLUMN sync_mng.regist_rp_cs     IS 'regist zone repetar call sign';
COMMENT ON COLUMN sync_mng.pc_ipaddr        IS 'ip address';
COMMENT ON COLUMN sync_mng.del_flg          IS 'delete flag';

-- $Id: ddl_create_table_unsync_multicast_mng.sql,v 1.1.1.1 2007/07/26 05:41:59 cvs Exp $
-- Unsync_Multicast Management table
--

drop table unsync_multicast_mng;
create table unsync_multicast_mng (
  multicast_cs	char(8) not null,
  mod_date		timestamp default now() not null,
  reg_date		timestamp default now() not null,
  arearp_cs_1	char(8),
  arearp_cs_2	char(8),
  arearp_cs_3	char(8),
  arearp_cs_4	char(8),
  arearp_cs_5	char(8),
  arearp_cs_6	char(8),
  arearp_cs_7	char(8),
  arearp_cs_8	char(8),
  arearp_cs_9	char(8),
  arearp_cs_10	char(8),
  constraint PK_UNSYNC_MULTICAST_MNG primary key (
    multicast_cs
  )
);

COMMENT ON TABLE unsync_multicast_mng IS 'unsync_Multicast Management table';
COMMENT ON COLUMN unsync_multicast_mng.multicast_cs IS 'multicast call sign';
COMMENT ON COLUMN unsync_multicast_mng.mod_date IS 'modify date for db';
COMMENT ON COLUMN unsync_multicast_mng.reg_date IS 'regist date for db';
COMMENT ON COLUMN unsync_multicast_mng.arearp_cs_1 IS 'area repetar call sign1';
COMMENT ON COLUMN unsync_multicast_mng.arearp_cs_2 IS 'area repetar call sign2';
COMMENT ON COLUMN unsync_multicast_mng.arearp_cs_3 IS 'area repetar call sign3';
COMMENT ON COLUMN unsync_multicast_mng.arearp_cs_4 IS 'area repetar call sign4';
COMMENT ON COLUMN unsync_multicast_mng.arearp_cs_5 IS 'area repetar call sign5';
COMMENT ON COLUMN unsync_multicast_mng.arearp_cs_6 IS 'area repetar call sign6';
COMMENT ON COLUMN unsync_multicast_mng.arearp_cs_7 IS 'area repetar call sign7';
COMMENT ON COLUMN unsync_multicast_mng.arearp_cs_8 IS 'area repetar call sign8';
COMMENT ON COLUMN unsync_multicast_mng.arearp_cs_9 IS 'area repetar call sign9';
COMMENT ON COLUMN unsync_multicast_mng.arearp_cs_10 IS 'area repetar call sign10';

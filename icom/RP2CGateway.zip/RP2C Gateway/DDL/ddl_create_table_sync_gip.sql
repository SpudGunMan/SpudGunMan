-- $Id: ddl_create_table_sync_gip.sql,v 1.1.1.1 2007/07/26 05:41:59 cvs Exp $
-- Unsync Global IP address table
-- 
drop table sync_gip;
create table sync_gip (
  zonerp_cs		char(8) not null,
  last_mod_time	timestamp not null,
  mod_date		timestamp default now() not null,
  reg_date		timestamp default now() not null,
  zonerp_ipaddr inet not null,
  del_flg		boolean default FALSE not null,
  constraint PK_SYNC_GIP primary key (
    zonerp_cs
  )
);

drop index IE1_SYNC_GIP;
create index IE1_SYNC_GIP on sync_gip (last_mod_time);

COMMENT ON TABLE sync_gip IS 'Sync Global IP address table';
COMMENT ON COLUMN sync_gip.zonerp_cs IS 'zone repetar call sign';
COMMENT ON COLUMN sync_gip.last_mod_time IS 'last modify date for sync';
COMMENT ON COLUMN sync_gip.mod_date IS 'modify date for db';
COMMENT ON COLUMN sync_gip.reg_date IS 'regist date for db';
COMMENT ON COLUMN sync_gip.zonerp_ipaddr IS 'zone repetar IP Address';
COMMENT ON COLUMN sync_gip.del_flg IS 'delete flag';

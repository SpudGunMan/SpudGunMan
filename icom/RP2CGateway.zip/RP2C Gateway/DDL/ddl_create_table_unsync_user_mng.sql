-- $Id: ddl_create_table_unsync_user_mng.sql,v 1.1.1.1 2007/07/26 05:41:59 cvs Exp $
-- Unsync_User Management table
-- 

drop table unsync_user_mng;
create table unsync_user_mng (
  user_cs		char(8) not null,
  mod_date		timestamp default now() not null,
  reg_date		timestamp default now() not null,
  e_mail		varchar(128) not null,
  password		varchar(32) not null,
  user_name		varchar(32) not null,
  admin_flg		boolean default FALSE not null,
  regist_flg	boolean default FALSE not null,
  constraint PK_UNSYNC_USER_MNG primary key (
    user_cs
  )
);

COMMENT ON TABLE unsync_user_mng IS 'Unsync_User Management table';
COMMENT ON COLUMN unsync_user_mng.user_cs IS 'user repetar call sign';
COMMENT ON COLUMN unsync_user_mng.mod_date IS 'modify date for db';
COMMENT ON COLUMN unsync_user_mng.reg_date IS 'regist date for db';
COMMENT ON COLUMN unsync_user_mng.e_mail IS 'Email Address';
COMMENT ON COLUMN unsync_user_mng.password IS 'Password';
COMMENT ON COLUMN unsync_user_mng.user_name IS 'user name';
COMMENT ON COLUMN unsync_user_mng.admin_flg IS 'admin flag';
COMMENT ON COLUMN unsync_user_mng.regist_flg IS 'regist flag';

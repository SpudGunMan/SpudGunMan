-- $Id: ddl_create_table_sync_rip.sql,v 1.1.1.1 2007/07/26 05:41:59 cvs Exp $
-- Sync Reserve IP Address table

drop table sync_rip;
create table sync_rip (
  user_cs			char(8)		not null,
  regist_rp_cs		char(8)		not null,
  last_mod_time		timestamp	not null,
  mod_date			timestamp	default now() not null,
  reg_date			timestamp	default now() not null,
  start_ipaddr		inet		not null unique,
  del_flg			boolean		default FALSE not null,
  constraint PK_SYNC_RIP primary key (
    user_cs,
    regist_rp_cs
  )
);

drop index IE1_SYNC_RIP;
create index IE1_SYNC_RIP on sync_rip (last_mod_time);

COMMENT ON TABLE sync_rip IS 'Sync Reserve IP Address table';
COMMENT ON COLUMN sync_rip.user_cs IS 'user repetar call sign';
COMMENT ON COLUMN sync_rip.regist_rp_cs IS 'regist zone repetar call sign';
COMMENT ON COLUMN sync_rip.last_mod_time IS 'last modify date for sync';
COMMENT ON COLUMN sync_rip.mod_date IS 'modify date for db';
COMMENT ON COLUMN sync_rip.reg_date IS 'regist date for db';
COMMENT ON COLUMN sync_rip.start_ipaddr IS 'start ip address';
COMMENT ON COLUMN sync_rip.del_flg IS 'delete flag';

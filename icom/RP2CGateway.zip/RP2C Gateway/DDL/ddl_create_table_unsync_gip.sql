-- $Id: ddl_create_table_unsync_gip.sql,v 1.1.1.1 2007/07/26 05:41:59 cvs Exp $
-- Unsync Global IP address table
--

drop table unsync_gip;
create table unsync_gip (
  zonerp_cs     char(8) not null,
  mod_date      timestamp default now() not null,
  reg_date      timestamp default now() not null,
  synchro_time  timestamp not null,
  allow_flg     boolean default TRUE not null,
  dbupdate_allow_flg        boolean default FALSE not null,
  constraint PK_UNSYNC_GIP primary key (
    zonerp_cs
  )
);

COMMENT ON TABLE unsync_gip IS 'Unsync Global IP address table';
COMMENT ON COLUMN unsync_gip.zonerp_cs IS 'zone repetar call sign';
COMMENT ON COLUMN unsync_gip.mod_date IS 'modify date for db';
COMMENT ON COLUMN unsync_gip.reg_date IS 'regist date for db';
COMMENT ON COLUMN unsync_gip.synchro_time IS 'last modify date for sync';
COMMENT ON COLUMN unsync_gip.allow_flg IS 'allow flg';
COMMENT ON COLUMN unsync_gip.dbupdate_allow_flg IS 'flg of allow update for db';

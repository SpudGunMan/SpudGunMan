-- $Id: ddl_create_sequence.sql,v 1.1.1.1 2007/07/26 05:41:59 cvs Exp $
-- Sequence: command_seq

DROP SEQUENCE command_seq;

CREATE SEQUENCE command_seq
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1
  CYCLE;
